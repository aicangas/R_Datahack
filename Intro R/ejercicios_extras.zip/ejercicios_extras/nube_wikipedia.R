install.packages('rvest')
install.packages('wordcloud2')
install.packages("digest")
install.packages('tm')
install.packages('RColorBrewer')
install.packages('dplyr')
install.packages("devtools")
##install.packages("digest", type="source")
## hay que instalarlo desde el menú y decirle que NO compile

#cargarlos paquetes
library(rvest)
library(tm)
library(dplyr)
library(wordcloud2)
library(RColorBrewer)


url <- "https://es.wikipedia.org/wiki/camino_de_santiago"

paragraphs = read_html(url) %>% html_nodes("p") %>% html_text()

documentos = VCorpus(VectorSource(paragraphs ) )

#toSpace <- content_transformer(function (x , pattern ) gsub(pattern, " ", x))


#documentos = tm_map(documentos, toSpace, "»")
#documentos = tm_map(documentos, toSpace, "«")
#documentos = tm_map(documentos, toSpace, "_")

documentos = tm_map(documentos,removeNumbers)

documentos = tm_map(documentos, removePunctuation)

documentos <- tm_map(documentos, content_transformer(tolower))

documentos = tm_map(documentos, removeWords, stopwords("spanish"))

#documentos = tm_map(documentos, removeWords, "dentro")

documentos <- tm_map(documentos, stripWhitespace)

tdm = TermDocumentMatrix(documentos)

m <- as.matrix(tdm)
v <- sort(rowSums(m),decreasing=TRUE)
d <- data.frame(word = names(v),freq=v)
head(d, 10)

d = d %>% filter(freq>2) 


browseURL( "https://www.r-graph-gallery.com/196-the-wordcloud2-library.html")

wordcloud2(data=d, size=1, color='random-light')
wordcloud2(data=d, size=1, color='random-dark')
wordcloud2(data=d, size=1, color='random-light', backgroundColor="black")

wordcloud2(data=d, shape = 'star')

nube_wikipedia <- function(
  pagina = "R (lenguaje de programación)",
  colores ='random-light',
  bck = 'white',
  forma = 'circle',
  minimo = 2,
  misma_palabra = F
  ) {
  pagina1 = gsub(" ", "_",pagina)
  pagina2 = URLencode(pagina1)
  url = paste0("https://es.wikipedia.org/wiki/",pagina2)
  paragraphs = read_html(url) %>% html_nodes("p") %>% html_text()
  documentos = VCorpus(VectorSource(paragraphs ))
  documentos = tm_map(documentos,removeNumbers)
  documentos = tm_map(documentos, removePunctuation)
  documentos <- tm_map(documentos, content_transformer(tolower))
  documentos = tm_map(documentos, removeWords, stopwords("spanish"))
  documentos <- tm_map(documentos, stripWhitespace)
  tdm = TermDocumentMatrix(documentos)
  m <- as.matrix(tdm)
  v <- sort(rowSums(m),decreasing=TRUE)
  d <- data.frame(word = names(v),freq=v)
  d = d %>% filter(freq>minimo) 
  if (misma_palabra==T) {
    lista = strsplit(pagina, " ") %>% unlist()
    d = d %>% filter(!word %in% tolower(lista)) 
  }
  wordcloud2(data=d, size=1, color=colores,backgroundColor = bck,shape = forma)
}

nube_wikipedia()
nube_wikipedia("aranjuez")
nube_wikipedia("aranjuez",misma_palabra = T)
nube_wikipedia("python",forma='star',misma_palabra = T,minimo = 1)
nube_wikipedia("Dos_Hermanas",misma_palabra = T)
nube_wikipedia("Cristóbal Colón",misma_palabra = T,colores = 'random-dark',bck='aqua')


