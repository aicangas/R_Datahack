install.packages('leaflet')
install.packages('ggvoronoi')
install.packages('dplyr')


library(leaflet)
library(ggvoronoi)
library(dplyr)
library(readxl)

###########################mapa voronoi españa

browseURL('https://es.wikipedia.org/wiki/Pol%C3%ADgonos_de_Thiessen')


municipios_spain = read_xls("ejercicios/ejercicios_extras/municipios_spain.xls")

head(municipios_spain)


#nos quedamos con las ciudades que son capitales de provincia
capitales_spain = municipios_spain #%>% filter(capital == 1)

capitales_spain %>% head()

#seleccionamos solamente el nombre, la latitud y la longitud
capitales_spain = capitales_spain %>% select(Población, Latitud, Longitud)


# a afectos de la visualización eliminamos las capitales canarias
capitales_spain = capitales_spain #%>% filter(Latitud >0)


# cargamos el mapa base
mapa_spain=leaflet()  %>% addProviderTiles(providers$Stamen.Toner)

mapa_spain
capitales_spain = capitales_spain %>% as.data.frame()

# creamos los polígonos de voronoi
voronoi_spain = voronoi_polygon(capitales_spain %>% select(-Población) %>% distinct(), x='Longitud', y='Latitud')


mapa_spain = mapa_spain %>% 
  addMarkers(
    lng=capitales_spain$Longitud, 
    lat=capitales_spain$Latitud, 
    popup=capitales_spain$Población
    )

mapa_spain


mapa_spain %>% addPolygons(data=voronoi_spain, fillOpacity = 0, color='red')



browseURL('http://urban-networks.blogspot.com/2020/02/delimitacion-racional-e-irracional-de.html')


####################################### mapa voronoi mundial

capitales = read_xlsx("ejercicios/ejercicios_extras/concap.xlsx") %>% 
  select(CapitalName,CapitalLongitude,CapitalLatitude,CountryName) %>% 
  distinct()

mapa = leaflet()

mapa 

mapa = mapa %>% addTiles(urlTemplate = "http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png")

mapa 

capitales = capitales %>% as.data.frame()

voronoi_world = voronoi_polygon(capitales, x='CapitalLongitude', y='CapitalLatitude')


mapa = mapa %>%  addMarkers(
  lng=capitales$CapitalLongitude, 
  lat=capitales$CapitalLatitude, 
  popup=paste(capitales$CapitalName,",",capitales$CountryName)
  )


mapa

mapa %>% addPolygons(data=voronoi_world, fillOpacity = 0, color='red')







