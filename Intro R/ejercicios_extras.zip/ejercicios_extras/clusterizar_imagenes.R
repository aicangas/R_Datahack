install.packages('ggplot2')
install.packages('jpeg')
install.packages('cluster')
install.packages('dplyr')



library(ggplot2)
library(jpeg)
library(cluster)
library(dplyr)

# descargamos la imagen de internet
url<- "https://i.pinimg.com/736x/15/95/05/1595057eb956154fe1bea7c5fbb9b650--colorful-houses-colorful-rooms.jpg"

url = "https://static6.depositphotos.com/1167801/651/i/450/depositphotos_6517777-stock-photo-rainbow-of-colorful-boxes.jpg"

url = "https://pbs.twimg.com/profile_images/640666088271839233/OTKlt5pC_400x400.jpg"


temporal <- tempfile()
download.file(url,temporal,mode="wb")
img <- readJPEG(temporal)


#dimensiones de la imagen
imgDm<-dim(img)
imgDm

print(paste("Tu imagen tiene un total de", as.character(imgDm[1]*imgDm[2]),"pixels"))
# creamos un dataframe que contenga las cordenadas x,y de la imagen y el RGB

imgRGB <- data.frame(
  x = rep(1:imgDm[2], each = imgDm[1]),
  y = rep(imgDm[1]:1, imgDm[2]),
  R = as.vector(img[,,1]),
  G = as.vector(img[,,2]),
  B = as.vector(img[,,3])
)

browseURL('https://www.december.com/html/spec/colorper.html')

imgRGB %>% head()
imgRGB %>% tail()



# hacemos un gráfico de la imagen original
ggplot(data = imgRGB, aes(x = x, y = y)) + 
  geom_point(colour = rgb(imgRGB[c("R", "G", "B")])) +
  labs(title = "Imagen Original") +
  xlab("x") +
  ylab("y")


k<-5# definimos el número de colores que queremos extraer

clarax<-clara(imgRGB[, c("R", "G", "B")],k)

clarax

# convertimos los colores a exadecimal
colores<-rgb(clarax$medoids)

colores

#creamos una lista con los colores para cada uno de los pixeles
rgb.cluster<-rgb(clarax$medoids[clarax$cluster,])

rgb.cluster[1:10]


#hacemos una representación de los medioides de los cluster 
image(1:k,1,as.matrix(1:k),col=colores,xlab="Medioides",
      ylab="",xaxt="n",yaxt="n",bty="n")

#generamos la imagen utilizando solamente los colores resultantes del cluster
ggplot(data =imgRGB, aes(x = x, y = y)) + 
  geom_point(colour = ( rgb.cluster)) +
  labs(title = paste("Clara Clustering con", k, "Colores")) 


file.remove(temporal) # borramos la imagen
