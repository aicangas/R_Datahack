install.packages("readxl")
install.packages("tidyverse")
install.packages("gifski")





#fuente de los datos 
browseURL("https://ourworldindata.org/coronavirus-source-data")

library(readxl)
library(tidyverse)
library(gganimate)

covid_data = read_excel("covid_data.xlsx")

covid_data


# nos quedamos con el top 20 de paises por número de fallecidos

covid_data %>% 
  filter(location!='World') %>% 
  group_by(location) %>% 
  mutate(maximo = rank(desc(total_deaths))) %>% 
  filter(maximo==1) %>% 
  ungroup() %>% 
  arrange(desc(total_deaths)) %>% 
  head(20) -> top


# filtramos para quedarnos con el evolutivo de esos 20 paises

covid_data %>% 
  inner_join(top %>% select(location)) %>% 
  select(location,date,total_deaths) %>% 
  replace_na(list(total_deaths = 0))-> muertes


muertes %>% select(location) %>% distinct()

# incorporamos china y filtramos a partir de la primera muerte reportada
muertes %>% 
  union_all(
    covid_data %>% 
      filter(location=='China') %>% 
      select(location,date,total_deaths)
    ) %>% 
  filter(date >= "2020-01-11")-> muertes



# creamos la columna ranking para cada dia en base al numero de fallecidos
muertes %>% 
  group_by(date) %>%
  mutate(rank = row_number(-total_deaths )) %>% 
  arrange(date, rank) %>% 
  ungroup() -> muertes





# generamos los gráficos estáticos

staticplot = ggplot(
  muertes, aes(rank, group = location, 
                     fill = as.factor(location), color = as.factor(location))) +
  geom_tile(aes(y = total_deaths/2,
                height = total_deaths,
                width = 0.9), alpha = 0.8, color = NA) +
  geom_text(aes(y = 0, label = paste(location, " ")), vjust = 0.2, hjust = 1) +
  geom_text(aes(y=total_deaths,label = total_deaths, hjust=0)) +
  coord_flip(clip = "off", expand = FALSE) +
  scale_y_continuous(labels = scales::comma) +
  scale_x_reverse() +
  guides(color = FALSE, fill = FALSE) +
  theme(axis.line=element_blank(),
        axis.text.x=element_blank(),
        axis.text.y=element_blank(),
        axis.ticks=element_blank(),
        axis.title.x=element_blank(),
        axis.title.y=element_blank(),
        legend.position="none",
        panel.background=element_blank(),
        panel.border=element_blank(),
        panel.grid.major=element_blank(),
        panel.grid.minor=element_blank(),
        panel.grid.major.x = element_line( size=.1, color="grey" ),
        panel.grid.minor.x = element_line( size=.1, color="grey" ),
        plot.title=element_text(size=25, hjust=0.5, face="bold", colour="grey", vjust=-1),
        plot.subtitle=element_text(size=18, hjust=0.5, face="italic", color="grey"),
        plot.caption =element_text(size=8, hjust=0.5, face="italic", color="grey"),
        plot.background=element_blank(),
        plot.margin = margin(2,2, 2, 4, "cm"))



# creamos la animación
anim = staticplot + transition_states(date, transition_length = 4, state_length = 1) +
  ease_aes('sine-in-out') + 
  view_follow(fixed_x = TRUE)  +
  labs(title = 'Fallecimientos por Covid-19: {closest_state}',  
       subtitle  =  "Top 20 Paises",
       caption  = "Fuente: https://ourworldindata.org")


# lo guardamos en un gif para poder visualizarlo
animate(anim, 200, fps = 10,  width = 1200, height = 1000, 
        renderer = gifski_renderer("gganim.gif"))

                                                      
