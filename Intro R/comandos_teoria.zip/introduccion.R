help.start()

help(mean)
?mean


help.search("mean")
??mean

example("mean")
