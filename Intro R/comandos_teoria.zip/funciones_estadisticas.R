ages = c(25,22,18,20,22,26, 89, 85)
ages

length(ages)

min(ages)

max(ages)



mean(ages)

median(ages)

sd(ages)

var(ages)

#summary

summary(ages)

boxplot(ages)

boxplot(iris)


###distribuciones

help("Distributions")

x <-rnorm(100000,mean=100,sd=40) 

x[1:10]
sd(x)
mean(x)

hist(x)

plot(runif(1000))

#sample

set.seed(1238765)

sample(1:10,9,replace = T )



set.seed(126)

sample(1:10,6,replace=F, prob=rep(0.1,10))



bolas <- sample(1:10,20000, replace=T, prob=c(0.25,0.1, 0.25,rep(0.1,7)))

table(bolas)


monedaok = sample(1:2,100000, replace = T)

table(monedaok)

monedatrucada =  sample(1:2,100000, replace = T, prob=c(0.8,0.2))



table(monedatrucada)





#data frame con valores aleatorios


data <- data.frame(categoria  = rep(c("A","B","C"),100),
                   nota = sample(1:10,100,replace = T),
                   dato = rnorm(100, 100, 20)
                   )



# dataset ejemplo 

?datasets

library(help = "datasets")

rm(list=ls()) 

data("airquality")

airquality

rm(airquality)

?iris

library(ggplot2)
?msleep
