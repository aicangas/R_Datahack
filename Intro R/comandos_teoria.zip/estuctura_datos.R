# vectores
x <- 1:10
x


x <- 1:1000
x


c()

v = c(2,3,7,8,9,90)

c(1,3,45,6,7,4)


#seq rep

seq(0, 1,)


s<- seq(from=10, to= 20, by = 2)
s
?seq
seq(10,20,2)

rep

rep("Miguel",100)

#length
x <- 1:10
x


length(x)

#operaciones vectorizadas

x

x + 1

x2 = x * 2

x2


x == 4

x >= 4

#seleccion de elementos

x <- 11:18
x

x[3]

x[3:5]

x[c(3,5,7)]

# filtrado con operadores lógicos

x <- c(1,2,3,4,5,5,6,7,99)

length(x)

y <- c(T,T,F,F,F,T,T,T,T)


x[y]

vector = 1:100

vector[vector>75]


head(iris)

iris[iris$Petal.Length > 1.5,]


x[x>5]

resultado = x[y]

length(x)

length(resultado)

x[y]




#reemplazar
x <- 1:5
x

x[1] = 99

x

#vectores con nombres

x <- 1:3
x

names(x) <- c("pepe","ana","juanito")


x

x["juanito"]


#extra: como cambiar los nombres de un dataframe
names(iris) = c("a", "b", "c", "d", "e")

names(iris)

head(iris)

?names
x

x[2]
x["pepe"]

x<-unname(x)
x





#operciones en conjuntos
a <- 1:4
b <- 4:7

union(a,b)

intersect(a,b)

setdiff(a,b)

setdiff(b,a)


2 %in% a
2 %in% b


#ordenando

x <- c(3,1,3,4,5,2,3,2,2,1,3,4,5)
x

x = sort(x)
?sort
help(sort)
sort(x , decreasing   = T)

#contando elementos
x

table(x)

# numeros especiales
1/0

0/0

vector = c(1,NA,2)

is.na(vector)

mean(c(1,2,3,4,5,NA))

mean(c(1,2,3,4,5,NA), na.rm = T )

x = c(1,2,3,4,5,NA)


?mean
x <- c(1, NA, 0/0)
x

is.na(x)

is.nan(x)


# limpiar nulos de un vector
x <- c(1,2,NA,4,NA,5)


x


!is.na(x)

x[is.na(x)]



nulos<-is.na(x)
nulos

x[!nulos]




#####MATRICES

matrix(1:6, nrow = 3, ncol= 2
       )


matrix(1:6,2)

m <- matrix(1:6,nrow = 2, ncol = 3)
m

class(m)

dim(m)


matrix(11:16,nrow = 2, ncol = 3, byrow = T)

m<- matrix(11:16,2,3, T)




m[1,2]

m[1,2:3]

m[1:2,3]




m[c(1,2),3]

m[2]

m[-2]


m1<- matrix(11:16,2,3, T)

m2<- matrix(11:16,2,3)


m1[c(-2,-4)]
m2[c(-2,-4)]

mat <- matrix(c(1,2,3,4),2,2,T)

mat

t(mat)

class(mat)

mat + mat

mat * mat

mat %*% mat

#matriz traspuesta
m = matrix(1:12,3,4)
m

t(m)

# cbind rbind

cbind(1:10,101:110)

rbind(1:5, 101:105, 100)

m1 = cbind(1:10,101:110)

m2 = cbind(2:11, 102:111 )

dim(m1)
dim(m2)

cbind(m1,m2)

rbind(m1,m2)





######LISTAS


x <- list(1, c("a","b"), T , 1 + 4i,iris %>% head(4))
x


x[[2]][2]



x[[5]]$Petal.Length[3]

x[[2]]


clientes = c('a', 'b', 'c')

mapa = leaflet() %>% addTiles() %>% addMarkers(-3,40)


lista = list(clientes, mapa)
lista[[1]]

lista[[2]]


#como guardar RDS (formato propio de R)
lista %>% saveRDS("comandos_teoria/borrame.rds")


lista %>% saveRDS("borrame.rds")

lista_new = readRDS("comandos_teoria/borrame.rds")

class(x[[5]])

x[[5]]

class(x)

l <- list(1:4 , c("a","b"))

l

l[[1]]

l[[2]]

l[[c(1,3)]]

l[[c(2,1)]]


l[[1]][3]

l[[2]][1]

x[[5]]$Sepal.Length

#listas con nombres

l <- list("numeros" = 1:3,"letras" = c("a","b","c")) 
l

l$numeros


l$letras

#unlist

l <- list(1:3,5:8)
l


y <- list(1:4,c("a","b","c"))

y

unlist(y)


metalista = list(l, 1:2)


metalista[[1]][[2]]

unlist(y)


unlist(l)



#### Dataframes

nombre <- c("lucia","antonio","juan","maria","pepe")
edad <- c(23,34,56,65,45) 
suscrito <- c(T,F,F,T,F)
df <- data.frame(nombre,edad,suscrito)
df




library(dplyr)
tibble(nombre, edad,suscrito)


df_dplyr = tibble(nombre,edad,suscrito)

df_dplyr

df$nombre

df$nombre
df$edad
df$suscrito

df[c("nombre","edad")]
df["edad"]
df["suscrito"]


df %>% select(suscrito, edad)


df %>% select(-suscrito)

###### crear una columna

df$id <- 1:5
df

df$id_letra = LETTERS[1:5]

#crear una columna de id para cada usuario

df$id <- 1:length(df$nombre)


# como hacerlo con la función mutate
df %>%  
  mutate(z=1:length(df$nombre)) -> df

#edad multiplicada por 2 (clasica)

df$edad2 = df$edad * 2


#edad multiplicada por 2 (dplyr)
df %>% 
  mutate(edad2_d = edad * 2) -> df

#borrado de forma clasica
df$z = NULL
df$edad = NULL


#select negativo de lo que no queremos
df %>%  select(-id, -edad) -> df2


rm(df)


#filtrar dfs 

df$edad > 50

df[df$edad > 50 ,]

df[df$edad > 50 & df$suscrito == FALSE,]

df[!df$suscrito,]

df[df$edad > 50 & !df$suscrito,c("nombre","suscrito")]


df %>%         
  filter(edad>50 & !suscrito) %>% 
  select(nombre, suscrito)
  







# inserta

df_insertar = data.frame(nombre="Jose Luis", edad =30,suscrito= F)



#insertar columna posicion

df2 %>% 
  mutate(nueva = edad/2, .after=nombre)


df2<- rbind(df2, df_insertar) 

df2 %>% union(df_insertar) 

names(df)

names(df) <- c("nombre","edad","producto")

df  = df %>% 
  rename(suscrito = producto)


row.names(df)


#### seleccion de columnas
df[c(1,3)]

df[1:3,c("nombre","edad")]

df$nombre

df %>% select(edad)
df["edad"]


df$nombre[2]


df %>% select(nombre) %>% .[2,]


condicion_filtrado = df$edad > 50

df[condicion_filtrado,]

df[ df$edad > 50,]

df %>% filter(edad>50)


#nueva columna

df$id <- 1:5

df %>% mutate(id_2 = 1:5 ) -> df

df


#borrado

df$id_2<-NULL

df



#insertar

df_insertar <- data.frame(nombre='Pepe',edad=30,suscrito=T)

df_insertar

df<-rbind(df,df_insertar)
df

dplyr::un

df %>% union_all(df_insertar) 

# nombnres de columnas
names(df)

row.names(df)

names(df) <- c ("nombre2"  , "edad"  ,  "suscrito")

df %>% rename(nombre = nombre2) -> df



#seleccionar columnas
df["nombre"]

df[1]

df[c("nombre","suscrito")]

  df[c(1,3)] 


df %>% 
  select(1,2,3)




df %>% select(nombre, edad)


df 



#filtrar filas

df[1:3,]

df[1:3,c(1,2)]

df[c(T,T,F,F,T,T),]

## filtado por condiciones


df[df$edad>40,]

filtrado <- df$edad>40
filtrado

df[filtrado,]

df %>% 
  filter(edad > 40) 

df[df$edad>50 & df$suscrito,]


df[df$edad>50 & df$suscrito,]

names(df) = c("edad", "nombre", "suscrito")


df[df$edad>50 & df$suscrito,c("nombre","edad")]

df %>% filter(edad>50 & suscrito) %>% select(nombre,edad)

df[df$edad>60 | df$suscrito,]

df %>% filter(edad>60 | suscrito)


select(df, Nombre)

df %>% select(Nombre)




#### codigo dplyr
msleep %>% head() 

df[df$dad > 40,]


df$id = 1:5

df %>% select(edad, id, nombre, suscrito)
  
  
# crear columna en posicion especifica  
library(tibble)
dataset <- data.frame(a = 1:5, b = 2:6, c=3:7)
add_column(dataset, d = 4:8, .after = 2)
  


### manejo de datos con dplyr

#install.packages("ggplot2")


library(ggplot2)


library(tidyverse)

?msleep

head(msleep, 10)

# forma tradicional
select(msleep, name, sleep_total)

# con pipes
msleep %>% 
  select( name, sleep_total) %>% 
  head()


  
msleep %>% select(-name, -genus) %>% head 


#filtros
msleep %>% filter(sleep_total >=16 ) %>% head()

msleep %>% filter(sleep_total >=16 & bodywt>=1) %>% head



#ordenar
msleep %>% arrange(desc(sleep_total)) %>% head(3)

msleep %>% arrange(vore, -(sleep_total)) %>% as.data.frame()



# crear una columna


msleep$rem_proportion = msleep$sleep_rem / msleep$sleep_total

msleep %>% 
  mutate(rem_proportion  = sleep_rem/sleep_total) -> msleep



msleep %>% 
  mutate( rem_proportion2 = 
    case_when(
      is.na(rem_proportion) ~ 0 ,
      T ~ rem_proportion)
  
  )
        
        
        


df %>%  
  mutate(categoria = 
           case_when(
             Edad > 40 & Suscrito ~ "Mayor y suscrito" ,
             Edad > 40 & !Suscrito ~ "Mayor no suscrito",
             Edad <= 40 & Suscrito ~ "Menor y suscristo", 
             Edad <= 40 & !Suscrito ~ "Menor y suscristo", 
           #  T ~ "no lo estas contemplando en el case",
           #  T ~ "Menor y suscrito"
           )) 


#case when (cuando pasa algo ) entonces (then) VALOR, when (cuando pasa otra cosa ) entonces VALOR2, else (para todo lo demás ) VALOR3



msleep %>% summarise(avg = mean(sleep_rem, na.rm = T))

msleep %>% 
  group_by(vore) %>% 
  filter(!is.na(vore)) %>% 
  summarise(
    avg = mean(sleep_rem, na.rm = T),
    maximo = max(sleep_rem, na.rm = T),
    minimo = min(sleep_rem,na.rm = T),
    conteo = n()
    ) -> mslepp_agrupado


msleep %>% 
  filter(!is.na(vore)) %>% 
  group_by(vore ) %>% 
  summarise(
    avg = mean(sleep_total), 
    maximo=max(sleep_total),
    minimo = min(sleep_total)
    ) %>% 
  arrange(desc(avg))


### replicamos el ejemplo de flights de Hadley Wickham
install.packages("nycflights13")
library(nycflights13)


filter(
summarise(
group_by(
filter(flights, !is.na(dep_delay)),
hour),
delay = mean(dep_delay),
n = n()),
n>10000)


# filtro el dataframe flights por los que tengan informado 
#el dep_delay agrupo por hora de salida del vuelo,
# caluclo la media del retraso y número de vuelos,
# filtro las horas donde tengamos al menos 10 vuelos

flights %>% 
  filter(!is.na(dep_delay)) %>% 
  group_by(hour) %>% 
  summarise(
    delay = mean(dep_delay),
    n = n()
  ) %>% 
  filter(n > 10000)

vuelos = readRDS("ejercicios/flights.rds")



