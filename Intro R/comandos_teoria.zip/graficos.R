plot(Sepal.Length ~ Petal.Length, data= iris)


plot(iris$Sepal.Length ~ iris$Petal.Length)

# scaterr plot



plot(airquality$Temp,airquality$Ozone)

?pressure

plot(pressure,type='l')


points(pressure$temperature,pressure$pressure)
lines(pressure$temperature, pressure$pressure /2, col = 'red')
points(pressure$temperature, pressure$pressure /2, col = 'red')

?mtcars 


table(mtcars$cyl)

barplot(table(mtcars$cyl))

hist(mtcars$mpg)

hist(mtcars$mpg , 2)


boxplot(len ~ supp , data= ToothGrowth)

cyltable <- table(mtcars$cyl)
cyltable

pie(cyltable,labels = names(cyltable))

plot(iris)

plot(mtcars)

Orange



library(lattice)

xyplot(iris$Sepal.Length~iris$Petal.Length|iris$Species)


library(ggplot2)
ggplot(
  data=iris, 
  aes(x=Sepal.Length, y = Sepal.Width)
  ) + geom_point() + stat_smooth()


ggplot(midwest, aes(x=area, y=poptotal)) + geom_point()

g <- ggplot(midwest, aes(x=area, y=poptotal)) +
  geom_point() +
  geom_smooth(method="lm") # set se=FALSE to turnoff confidence bands
plot(g)


g1 <- g + coord_cartesian(xlim=c(0,0.1), ylim=c(0, 1000000)) # zooms in plot(g1)
plot(g1)

g1 + labs(title="Area Vs Population", 
          subtitle="From midwest dataset",
          y="Population",
          x="Area", 
          caption="Midwest Demographics")
# or
g1 + ggtitle("Area Vs Population", subtitle="From midwest dataset") + xlab("Area") + ylab("Population")


ggplot(midwest, aes(x=area, y=poptotal)) +
  geom_point(col="steelblue", size=3) + # Set static color and size for points geom_smooth(method="lm", col="firebrick") + # change the color of line coord_cartesian(xlim=c(0, 0.1), ylim=c(0, 1000000)) +
  labs(title="Area Vs Population", subtitle="From midwest dataset", y="Population", x="Area", caption="Midwest Demographics")


gg <- ggplot(midwest, aes(x=area, y=poptotal)) +
  geom_point(aes(col=state), size=3) + # Set color to vary based on state categories.
  geom_smooth(method="lm", col="firebrick", size=2) +
  coord_cartesian(xlim=c(0, 0.1), ylim=c(0, 1000000)) +
  labs(title="Area Vs Population", subtitle="From midwest dataset", y="Population", x="Area", caption="Midwest Demographics")
plot(gg)


#leaflet

#install.packages("leaflet")
library(leaflet)
m <- leaflet() %>%
  addTiles() %>% # Add default OpenStreetMap map tiles 
  addMarkers(lng=174.768, lat=-36.852, popup="The birthplace of R")
  m # Print the map
  
  
  m <- leaflet() %>% setView(lng = -71.0589, lat = 42.3601, zoom = 8) 
  m%>% addTiles()
  m %>% addProviderTiles(providers$Stamen.Toner)
  m %>% addProviderTiles(providers$Esri.NatGeoWorldMap)
  
  m %>% addProviderTiles( providers$CartoDB)
  
  providers$CartoDB
  
  
  data(quakes)
  # Show first 20 rows from the `quakes` dataset 
  leaflet(data = quakes[1:20,]) %>% addTiles() %>%
  addMarkers(~long, ~lat, popup = ~as.character(mag), label = ~as.character(mag))

  
  leaflet(quakes) %>% addTiles() %>% addMarkers( clusterOptions = markerClusterOptions())

  
install.packages("highcharter")
install.packages("palmerpenguins")
install.packages("forecast")
install.packages("quantmod")
library(highcharter)

data(penguins, package = "palmerpenguins")
hchart(penguins, "scatter", hcaes(x = flipper_length_mm, y = bill_length_mm, group = species))

x <- c(rnorm(10000), rnorm(1000, 4, 0.5))

hchart(x, name = "data")

library(forecast)
airforecast <- forecast(auto.arima(AirPassengers), level = 95)
hchart(airforecast)


library(quantmod)
x <- getSymbols("GOOG", auto.assign = FALSE) 
y <- getSymbols("AMZN", auto.assign = FALSE)

highchart(type = "stock") %>% 
  hc_add_series(x) %>% 
  hc_add_series(y, type = "ohlc")
