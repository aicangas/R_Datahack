install.packages("corrplot")
library(corrplot)

M <- cor(mtcars)
corrplot(M, method = "ellipse")

corrplot()
