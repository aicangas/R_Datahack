rep

c

sum


name <- function(variables) {
  
}



suma2 <- function(x,y) {
  output<- x + y
  return(output)
}

suma2(8,14)

suma2bis  <- function(x,y) {
  x + y
}

suma2bis(4,34)



fmaximo <- function(v,f=max) {
  output<- f(v)
  return(output)
}

fmaximo(1:100)

fmaximo(1:100, min)

fmaximo <- function(v = 1:5,f=max) {
  output<- f(v)
  return(output)
}

fmaximo()

valores <- 1:34

fmaximo(valores)



# estructuras de control

?Control


fmultiplication <- function(v,m=2) {
  if(v[1] >5)
  {
    return(v*10)
  }
  else
  {
      return(v*m)
    }
}


fmultiplication(1:20)


## bucle for

for (k in 1:8) {
  print(1:k)
}

## bucle repeat

x = 0
repeat{
  print(x)
  if (x >= 10) break 
  x <- x + 1  
}

## bucle while

x <- 1

while (x <= 10) {
  print(x)
  x <- x + 1
}

##next
for (i in 1:10) {
  if (i %in% 4:7) {
    next
    }
  else {
    print(i)
    }
}






