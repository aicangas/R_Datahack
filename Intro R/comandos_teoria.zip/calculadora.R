3 + 2

2 - 1

2 * 4

4 / 2

2 ^ 2 

2 ** 2 

5 %% 2

5 %/% 2

resultado = 2**2

resultado * 10

sqrt(4)


4 < 5

4 <= 4

4 > 5

4 == 4

4 != 4

!0

!1



!TRUE

!T

!FALSE

!F


FALSE | TRUE 

FALSE & TRUE



isTRUE(F)



# VARIABLES

y <- 4

variable = 1/6

y = 4

x <- 8


x

x = 2

x2 = x * 2

x2




# "Alt" + "-"



x = 3


X

variable

# tipo de las variables

a <- 4
b <- 4L
c <- (5 + 3i)
d <- T
e <- "palabra"




print(a)
print(b)
print(c)
print(d)
print(e)

a
b
c
d
e

class(a)
class(b)
class(c)
class(d)
class(e)

texto = "324"
class(texto)

texto + 1

#conversion de tipos

help(seq)

x <- 0:6
x

class(x)

as.numeric(x)

as.character(x)


as.integer(c(1.2,2.4))

as.char

as.integer()
as.character()
as.logical(x)

x = as.logical(x)


x * 2

as.integer(-3.5)

floor(5.7)

