install.packages('swirl')
library(swirl)

install_from_swirl("R Programming")
install_from_swirl("Getting and Cleaning Data")
install_from_swirl("Open Intro")
swirl()

#| -- Typing skip() allows you to skip the current question.
#| -- Typing play() lets you experiment with R on your own; swirl will ignore what you do...
#| -- UNTIL you type nxt() which will regain swirl's attention.
#| -- Typing bye() causes swirl to exit. Your progress will be saved.
#| -- Typing main() returns you to swirl's main menu.
#| -- Typing info() displays these options again.

#leyedo datos
getwd()

?read.csv

data <- read.csv("datos/iris.data",header = T) 
head(data)

data_url <- read.csv(url("http://www.sharpsightlabs.com/wp-content/uploads/2016/04/unknown_fxn_data.txt"))

data_url

# escribir

mtcars
write.csv(mtcars,"datos/mtcars.csv")


write.table(data, file = 'datos/data.txt', sep="|", row.names=F, col.names=F)

write.csv(data,file='datos/data.csv')

data2 <- readLines('datos/access.log')
data2[1:5]

writeLines(data2,con="datos/data2.txt")


##guardar y cargar rds
saveRDS(data,file = "datos/datos.rds")

readRDS("datos/datos.rds")
