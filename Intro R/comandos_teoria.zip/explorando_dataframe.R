?airquality
?iris


dim(airquality)


ncol(airquality)

nrow(airquality)

names(airquality)

head(airquality,25)


airquality %>% head(25)

tibble(airquality)

tail(airquality,5)

mean(airquality$Solar.R,na.rm = T)

summary(airquality)

summary(na.omit(airquality))


mean(airquality$Ozone,na.rm = T)

str(airquality)


table(airquality$Month)

table(airquality$Month,airquality$Day)
