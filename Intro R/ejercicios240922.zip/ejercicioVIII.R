#Crear una función que tome dos valores de entrada y devuelva el resultado de restar el segundo al primero
f_restar <- function(x, y) {
  output <- x - y
  return(output) }

f_restar(8,5)

# Crear una función que calcule la media de un vector
f_media <- function(a) {
  output <- mean(a)
  return(output) }

f_media(0:100)
