#La cantidad de zinc (en mg/l) en 16 muestras de alimentos infantiles viene dada por:
#  (3.0, 5.8, 5.6, 4.8, 5.1, 3.6, 5.5, 4.7, 5.7, 5.0, 5.9, 5.7, 4.4, 5.4, 4.2, 5.3) 
#Hallar media, desviación típica, mediana, cuartiles, y dibujar el box-plot e histograma.
x <- c(3.0,5.8,5.6,4.8,5.1,3.6,5.5,4.7,5.7,5.0,5.9,5.7,4.4,5.4,4.2,5.3)

#media
mean(x)
#desviacion
sd(x) 
#summary
summary(x)

# boxplot
boxplot(x, ylab="zinc (mg/l)")

# histograma
hist(x,main="zinc en alimentos infantiles", xlab="zinc (mg/l)")
