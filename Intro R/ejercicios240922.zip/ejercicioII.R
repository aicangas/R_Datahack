x <-  45
y <-  6
z =  x + y 

print(x)
print(y)
print(z)

x
y
z


class(x)
class(y)
class(z)


a <- z / 2

a

class(a)

typeof(a)

help(class)

as.integer(a)

a

a <- as.integer(a)


ai

class(ai)
