#Usa los comandos read.csv y read.table para cargar el archivo iris.data y asignarlos a data” y “data2”
data <- read.csv("datos/iris.data", header=T)
data

data2 <- read.table("datos/iris.data", header=T, sep=",")
data2

# Guarda los resultados con write.csv y write.table, respetivamente 
write.csv(data, file="datos/data.csv", row.names = F, col.names = F)
write.table(data2, file="datos/data.txt", sep = '|', row.names = F, col.names = F)

# Usar la función url(), junto con read.csv para cargar el archivo de la siguiente url:
 # http://www.sharpsightlabs.com/wp-content/uploads/2016/04/unknown_fxn_dat a.txt
url("http://www.sharpsightlabs.com/wp-content/uploads/2016/04/unknown_fxn_data.txt")

data_url <-read.csv(url("http://www.sharpsightlabs.com/wp-content/uploads/2016/04/unknown_fxn_data.txt"))

#Carga el archivo access.log con readLines() 
data3 <- readLines('datos/access.log')

str(data3)

# Carga el archivo test.csv y guárdalo como test.rda 
testdata <- read.csv("datos/test.csv")
saveRDS(testdata, file = "datos/test.rds")

#Compara la velocidad de carga de test.csv y test.rda, usando los siguientes comandos:
system.time(read.csv("datos/test.csv"))
system.time(readRDS("datos/test.rds"))

